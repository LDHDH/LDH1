package kr.ac.mjc.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    public ArrayList<User> list() {
        List<User> userList=userRepository.findAll();
        return (ArrayList<User>)userList;
    }

    public User getitem(String id) {
        Optional<User> user=userRepository.findById(id);
        return user.get();
    }

    public void saveUser(User user){
        userRepository.save(user);
    }

    public void deleteUser(String id){
        userRepository.deleteById(id);
    }
}
