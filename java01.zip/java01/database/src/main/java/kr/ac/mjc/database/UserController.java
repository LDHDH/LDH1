package kr.ac.mjc.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("/list")
    public ResponseEntity< ArrayList<User> > list() {
        ArrayList<User> userList=userService.list();
        return ResponseEntity.ok(userList);
    }

    @GetMapping("/item")
    public ResponseEntity<User> getItem(@RequestParam("id") String id) {
        User user=userService.getitem(id);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/create")
    public String create(@RequestBody User user) {
        userService.saveUser(user);
        return "success";
    }

    @DeleteMapping("/delete")
    public String delete(@RequestParam("id") String id){
        userService.deleteUser(id);
        return "success";
    }

}
