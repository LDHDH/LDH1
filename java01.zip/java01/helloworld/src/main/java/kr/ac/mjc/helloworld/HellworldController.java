package kr.ac.mjc.helloworld;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class HellworldController {


    @GetMapping("/hello")
    public String hello() {
        return "hello";
    }
    @PostMapping("/world")
    public ResponseEntity<HelloworldDTO> world(@RequestBody HelloworldDTO dto) {
        /*
        System.out.println(name);
        HelloworldDTO dto=new HelloworldDTO();
        dto.setName(name);
        dto.setAge(20);
        dto.setMen(true);
        dto.setWomen(false);
        return ResponseEntity.ok(dto);

         */
        
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/list")
    public ResponseEntity<ArrayList<HelloworldDTO>> list() {
        ArrayList<HelloworldDTO> list=new ArrayList();
        for(int i=0; i<100; i++){
            HelloworldDTO dto=new HelloworldDTO();
            dto.setName("이동훈"+i);
            dto.setAge(i);
            list.add(dto);
        }

        return ResponseEntity.ok(list);
    }
}
