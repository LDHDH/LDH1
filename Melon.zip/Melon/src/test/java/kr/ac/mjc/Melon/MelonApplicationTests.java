package kr.ac.mjc.Melon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MelonApplicationTests {

	@Test
	void contextLoads() {
	}

}
