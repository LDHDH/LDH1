package kr.ac.mjc.Melon.Controller;

import jakarta.servlet.http.HttpSession;
import kr.ac.mjc.Melon.Service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    @PostMapping("register")
    public String registerUser(@RequestParam("username") String username,
                               @RequestParam("password") String password,
                               Model model) {
        String message = userService.registerUser(username, password);
        model.addAttribute("message", message);
        return "register";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // login.html을 반환
    }


    @PostMapping("/login")
    public String loginUser(@RequestParam("username") String username,
                            @RequestParam("password") String password,
                            Model model,
                            HttpSession session) {
        // UserService의 validateUser 호출
        boolean isValid = userService.validateUser(username, password);
        if (isValid) {
            session.setAttribute("username", username);
            session.setAttribute("loginTime", System.currentTimeMillis());
            return "redirect:/charts";
        } else {
            model.addAttribute("message", "아이디 또는 비밀번호가 올바르지 않습니다.");
            return "login";
        }
    }


    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/charts";
    }
}
