package kr.ac.mjc.Melon.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import kr.ac.mjc.Melon.domain.Song;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PlaylistRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public void addSongToPlaylist(Long songId, Long playlistId) {
        // Playlist와 Song을 엔티티로 조회
        Playlist playlist = entityManager.find(Playlist.class, playlistId);
        Song song = entityManager.find(Song.class, songId);

        if (playlist == null || song == null) {
            throw new IllegalArgumentException("플레이리스트 또는 곡을 찾을 수 없습니다.");
        }

        // Playlist에 Song 추가
        playlist.getSongs().add(song);
        entityManager.merge(playlist);
    }
}
