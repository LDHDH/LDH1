package kr.ac.mjc.Melon.Service;

import kr.ac.mjc.Melon.domain.Song;
import kr.ac.mjc.Melon.repository.PlaylistRepository;
import kr.ac.mjc.Melon.repository.SongRepository;
import org.springframework.stereotype.Service;

@Service
public class SongService {

    private final SongRepository songRepository;
    private final PlaylistRepository playlistRepository;

    public SongService(SongRepository songRepository, PlaylistRepository playlistRepository) {
        this.songRepository = songRepository;
        this.playlistRepository = playlistRepository;
    }

    public Song getSongById(Long id) {
        return songRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("곡 정보를 찾을 수 없습니다."));
    }

    public void addToPlaylist(Long songId) {
        Song song = songRepository.findById(songId)
                .orElseThrow(() -> new IllegalArgumentException("플레이리스트에 추가할 곡을 찾을 수 없습니다."));
        playlistRepository.save(song);
    }

    public void incrementLikes(Long songId) {
        Song song = songRepository.findById(songId)
                .orElseThrow(() -> new IllegalArgumentException("좋아요를 추가할 곡을 찾을 수 없습니다."));
        song.setLikecount(song.getLikecount() + 1);
        songRepository.save(song);
    }
}

