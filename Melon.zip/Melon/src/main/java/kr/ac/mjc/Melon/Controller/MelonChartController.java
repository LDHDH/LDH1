package kr.ac.mjc.Melon.Controller;



import kr.ac.mjc.Melon.Service.MelonChartService;
import kr.ac.mjc.Melon.domain.MelonChart;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MelonChartController {
    private final MelonChartService melonChartService;

    public MelonChartController(MelonChartService melonChartService) {
        this.melonChartService = melonChartService;
    }

    @GetMapping("/charts")
    public String getMelonCharts(Model model) {
        List<MelonChart> charts = melonChartService.getAllCharts(); // 데이터 가져오기
        model.addAttribute("charts", charts); // 데이터 모델에 추가
        return "charts"; // charts.html로 렌더링
    }
}
