package kr.ac.mjc.Melon.Service;


import kr.ac.mjc.Melon.domain.MelonChart;
import kr.ac.mjc.Melon.repository.MelonChartRepository;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class MelonChartService {

    private final MelonChartRepository melonChartRepository;

    public MelonChartService(MelonChartRepository melonChartRepository) {
        this.melonChartRepository = melonChartRepository;
    }

    public List<MelonChart> getAllCharts() {
        List<MelonChart> charts = melonChartRepository.findAll();
        System.out.println("Fetched charts: " + charts); // 데이터 확인
        return charts;
    }
}

