package kr.ac.mjc.Melon.repository;

import kr.ac.mjc.Melon.domain.MelonChart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MelonChartRepository extends JpaRepository<MelonChart, Long> {
}
