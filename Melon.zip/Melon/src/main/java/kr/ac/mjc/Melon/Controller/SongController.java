package kr.ac.mjc.Melon.Controller;


import kr.ac.mjc.Melon.Service.SongService;
import kr.ac.mjc.Melon.domain.Song;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/song")
public class SongController {

    private final SongService songService;

    public SongController(SongService songService) {
        this.songService = songService;
    }

    @GetMapping("/{id}")
    public String getSongDetail(@PathVariable Long id, Model model) {
        Song song = songService.getSongById(id);
        model.addAttribute("song", song);
        return "song";
    }

    @PostMapping("/addToPlaylist")
    public String addToPlaylist(@RequestParam Long songId) {
        songService.addToPlaylist(songId);
        return "redirect:/song/" + songId;
    }

    @PostMapping("/like")
    public String likesong(@RequestParam Long songId) {
        songService.incrementLikes(songId);
        return "redirect:/song/" + songId;
    }
}

