package kr.ac.mjc.Melon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MelonApplication {

	public static void main(String[] args) {
		SpringApplication.run(MelonApplication.class, args);
	}

}
